<html>
 <head>
  <title>Ansible Application</title>
 </head>
 <body>

<?php

echo " Hello LAMP Stack installed successfully"

?>

</body>
</html>
